#include <LPC21xx.h>
#include "Delayheader.h"

#define LCD_D  (0xF<<8)
#define RS     (1<<12)
#define E      (1<<13)
#define sw     (1<<17)
#define BUZZER (1<<2)

unsigned int pen_cost    = 0;
unsigned int pencil_cost = 0;
unsigned int total       = 0;

void LCD_INIT(void);
void LCD_COMMAND(unsigned char);
void LCD_DATA(unsigned char);
void LCD_STRING(unsigned char *);
void LCD_INT(unsigned int);
void LCD_SCROLL(unsigned char *);

void LCD_LINE1(void);
void LCD_LINE2(void);
void LCD_READY(void);
void SHOW_CART(void);


void LCD_INIT(void)
{
    IODIR0 |= LCD_D | RS | E;
   
    delay_ms(20);

    LCD_COMMAND(0x02);
    LCD_COMMAND(0x28);
    LCD_COMMAND(0x0C);
    LCD_COMMAND(0x01);
    LCD_COMMAND(0x80);
}

void LCD_COMMAND(unsigned char c)
{
    IOCLR0 = LCD_D;
    IOSET0 = (c & 0xF0) << 4;
    IOCLR0 = RS;
    IOSET0 = E;
    delay_ms(2);
    IOCLR0 = E;

    IOCLR0 = LCD_D;
    IOSET0 = (c & 0x0F) << 8;
    IOCLR0 = RS;
    IOSET0 = E;
    delay_ms(2);
    IOCLR0 = E;
}

void LCD_DATA(unsigned char d)
{
    IOCLR0 = LCD_D;
    IOSET0 = (unsigned int)(d & 0xF0) << 4;
    IOSET0 = RS;
    IOSET0 = E;
    delay_ms(2);
    IOCLR0 = E;

    IOCLR0 = LCD_D;
    IOSET0 = (unsigned int)(d & 0x0F) << 8;
    IOSET0 = RS;
    IOSET0 = E;
    delay_ms(2);
    IOCLR0 = E;
}

void LCD_LINE1(void){ LCD_COMMAND(0x80); }
void LCD_LINE2(void){ LCD_COMMAND(0xC0); }

void LCD_STRING(unsigned char *str)
{
    while(*str) LCD_DATA(*str++);
}

void LCD_INT(unsigned int n)
{
    unsigned char a[6];
    signed char i=0;
    if(n==0){
			LCD_DATA('0');
			return;
		}
    while(n>0){
			a[i++]=n%10;
			n=n/10;
		}
		for(--i;i>=0;i--)
			LCD_DATA(a[i]+48);
}  
void LCD_SCROLL(unsigned char *str)
{
    unsigned int i, j, len = 0;

    while(str[len] != '\0')
        len++;

    for(i = 0; i < len; i++)
    {
        LCD_COMMAND(0x01);
        delay_ms(2);

        LCD_LINE1();

        for(j = 0; j < 16; j++)
        {
            if((i+j) < len)
                LCD_DATA(str[i+j]);
            else
                LCD_DATA(' ');
        }

        delay_ms(250);
    }
}

void SHOW_CART(void)
{
    IOSET0=BUZZER;
    delay_ms(1000);
    IOCLR0=BUZZER;
    LCD_COMMAND(0x01);
    delay_ms(2);
    LCD_LINE1();
    LCD_STRING("Pen:");
    LCD_INT(pen_cost);
    LCD_STRING(" Pcil:");
    LCD_INT(pencil_cost);
    LCD_LINE2();
    LCD_STRING("Totbill: Rs.");
    LCD_INT(total);
    delay_ms(3000);
}

void LCD_READY(void)
{                                      
    LCD_COMMAND(0x01);
    delay_ms(2);
    LCD_LINE1();
    LCD_STRING("Scan product... ");
}
