#include<lpc21xx.h>

int RFID_Read(unsigned char *);
unsigned char STR_EQ(unsigned char *, unsigned char *);


int RFID_Read(unsigned char *tag)
{
    static unsigned char i = 0;

    if(U0LSR & 0x01)
    {
        tag[i++] = U0RBR;

        if(i >= 12)
        {
            tag[12] = '\0';
            i = 0;
            return 1;      
        }
    }

    return 0;               
}

unsigned char STR_EQ(unsigned char *a, unsigned char *b)
{
    unsigned char i;
    for(i=0; i<12; i++)
        if(a[i]!=b[i]) return 0;
    return 1;
}
