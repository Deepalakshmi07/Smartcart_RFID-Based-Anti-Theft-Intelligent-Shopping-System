#include<lpc21xx.h>
#include "MP_LCD.c"
#include "MP_RFID.c"
#include "MP_uart.c"

unsigned char TAG_PEN[]     = "060067882FC6";
unsigned char TAG_PENCIL[]  = "060067A7DD1B";
unsigned char TAG_PAYMENT[] = "060067891DC6";

volatile int flag1 = 0;       
volatile int flag2 = 0;     
volatile int flag3 = 0;    
int paid_flag = 0;


int pen_flag    = 0;
int pencil_flag = 0;

void EINT0_ISR(void) __irq
{
    EXTINT = 0x01;
    flag1  = 1;
    VICVectAddr = 0;
}

void EINT1_ISR(void) __irq
{
    EXTINT = 0x02;
    flag2  = 1;
    VICVectAddr = 0;
}

	int main()
{
    unsigned char tag[13];

    LCD_INIT();
    UART0_CONFIG();

    PINSEL0 |= 0x00000005;
    PINSEL1 |= 0x00000001;
    PINSEL0 |= 0x20000000;
    PINSEL0 &= ~(0xc000000);

    IODIR0 &= ~((1<<14) | (1<<15) | (1<<16) | (1<<17) | (1<<18));
    IODIR0 |= BUZZER;

    VICIntSelect = 0x00;

    VICVectAddr0 = (unsigned long)EINT0_ISR;
    VICVectCntl0 = (1<<5) | 14;

    VICVectAddr1 = (unsigned long)EINT1_ISR;
    VICVectCntl1 = (1<<5) | 15;

    EXTMODE  = 0x03;
    EXTPOLAR = 0x00;
    EXTINT   = 0x03;

    VICIntEnable = (1<<14) | (1<<15);

    LCD_SCROLL("SMART CART: RFID BASED ANTI THEFT INTELLIGENT SHOPPING SYSTEM");

    LCD_READY();
    delay_ms(2000);
    
		
   while(1)
{
		int i;
   
    if((IOPIN0 & (1<<15)) == 0)
    {
        SHOW_CART();

        while((IOPIN0 & (1<<15)) == 0);

        delay_ms(200);
        LCD_READY();
    }
			
if((IOPIN0 & (sw)) == 0)
{
    delay_ms(50);

    if(total > 0 && paid_flag == 0)
    {
        LCD_COMMAND(0x01);

        LCD_LINE1();
        LCD_STRING("THEFT DETECTED");

        LCD_LINE2();
        LCD_STRING("PAY & SCAN BILL");

			for(i=0; i<10; i++)
			{
                IOSET0 = BUZZER;
                delay_ms(200);
                IOCLR0 = BUZZER;
		        delay_ms(200);

			}
    }
    else
    {
        LCD_COMMAND(0x01);

        LCD_LINE1();
        LCD_STRING("EXIT ALLOWED");

        LCD_LINE2();
        LCD_STRING("THANK YOU");

        delay_ms(5000);

        pen_cost = 0;
        pencil_cost = 0;
        total = 0;
        paid_flag = 0;

        LCD_READY();
    }

    while((IOPIN0 & (1<<17)) == 0);
}

    if(RFID_Read(tag))
    {
        if(STR_EQ(tag, TAG_PEN))
        {
            LCD_COMMAND(0x01);
            delay_ms(2);

            LCD_LINE1();
            LCD_STRING("Pen Scanned!");

            LCD_LINE2();
            LCD_STRING("SW1=Add SW2=Rem");

            flag1 = 0;
            flag2 = 0;

            while(flag1==0 && flag2==0)
            {
                if((IOPIN0 & (1<<15)) == 0)
                {
                    SHOW_CART();

                    while((IOPIN0 & (1<<15)) == 0);

                    delay_ms(200);

                    LCD_COMMAND(0x01);
                    LCD_LINE1();
                    LCD_STRING("Press SW1/SW2");
                }
            }

            if(flag1)
            {
                pen_cost += 10;
                total += 10;
                flag1 = 0;
            }
            else if(flag2)
            {
                if(pen_cost >= 10)
                {
                    pen_cost -= 10;
                    total -= 10;
                }

                flag2 = 0;
            }

            SHOW_CART();
        }

        else if(STR_EQ(tag, TAG_PENCIL))
        {
            LCD_COMMAND(0x01);
            delay_ms(2);

            LCD_LINE1();
            LCD_STRING("Pencil Scan");

            LCD_LINE2();
            LCD_STRING("SW1=Add SW2=Rem");

            flag1 = 0;
            flag2 = 0;

            while(flag1==0 && flag2==0)
            {
                if((IOPIN0 & (1<<15)) == 0)
                {
                    SHOW_CART();

                    while((IOPIN0 & (1<<15)) == 0);

                    delay_ms(200);

                    LCD_COMMAND(0x01);
                    LCD_LINE1();
                    LCD_STRING("Press SW1/SW2");
                }
            }

            if(flag1)
            {
                pencil_cost += 20;
                total += 20;
                flag1 = 0;
            }
            else if(flag2)
            {
                if(pencil_cost >= 20)
                {
                    pencil_cost -= 20;
                    total -= 20;
                }

                flag2 = 0;
            }

            SHOW_CART();
        }

        else if(STR_EQ(tag, TAG_PAYMENT))
        {
            LCD_COMMAND(0x01);
            delay_ms(2);

            LCD_LINE1();
            LCD_STRING("Bill PAID :-)");

            LCD_LINE2();
            LCD_STRING("Thank You!");

            IOSET0 = BUZZER;
            delay_ms(1000);
            IOCLR0 = BUZZER;

            pen_cost = 0;
            pencil_cost = 0;
            total = 0;

            delay_ms(2000);
        }
        else
        {
            LCD_COMMAND(0x01);
            LCD_LINE1();
            LCD_STRING("Unknown Tag");

            delay_ms(1000);
        }

        /* Clear tag after processing */
        tag[0] = '\0';

        LCD_READY();
    }
}
	} 







