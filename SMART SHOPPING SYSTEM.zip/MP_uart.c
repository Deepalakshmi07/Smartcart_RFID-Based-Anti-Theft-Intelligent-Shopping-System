#include<lpc21xx.h>

void UART0_CONFIG(void);
unsigned char UART0_RX(void);

void UART0_CONFIG(void)
{
    PINSEL0 |= 0x05;
    U0LCR   = 0x83;
    U0DLL   = 97;
    U0DLM   = 0;
    U0LCR   = 0x03;
}

unsigned char UART0_RX(void)
{
    while((U0LSR&0x01)==0);
    return U0RBR;
}
